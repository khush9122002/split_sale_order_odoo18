from odoo import api,models,fields
from odoo.exceptions import ValidationError


class SplitQuotationWizard(models.TransientModel):
    _name = 'split.order.wizard'
    _description = 'Split Quotation Wizard'

    product_lines = fields.One2many('split.order.line', 'wizard_id',)

    def split_order(self):
        new_sale_order = False 
        
        for line in self.product_lines:            
            if line.sale_order_line_id:
                previous_quantity = line.sale_order_line_id.product_uom_qty
                    
                if line.quantity <= previous_quantity:
                    updated_quantity = previous_quantity - line.quantity
                    line.sale_order_line_id.write({
                        'product_uom_qty': updated_quantity
                    })
                    
                    if not new_sale_order:
                        original_order = line.sale_order_line_id.order_id
                        new_sale_order = self.env['sale.order'].create({
                            'partner_id': original_order.partner_id.id,  
                            'pricelist_id': original_order.pricelist_id.id,
                            'user_id': original_order.user_id.id,  
                            'date_order': fields.Datetime.now(),  
                            'split_from': original_order.id, 
                        })
                    original_sale_order_line = line.sale_order_line_id
                    new_line_vals = {
                        'order_id': new_sale_order.id,
                        'product_id': original_sale_order_line.product_id.id,
                        'product_uom_qty': line.quantity,
                        'product_uom': original_sale_order_line.product_uom.id,
                        'price_unit': original_sale_order_line.price_unit,
                        'name': original_sale_order_line.name,

                    }
                    self.env['sale.order.line'].create(new_line_vals)
                    
                else:
                    raise ValidationError(
                        f"Split qty ({line.quantity}) is not high , Actual qty ({previous_quantity}) ."
                    )
        
        return True
    
    def action_cancel(self):
        pass