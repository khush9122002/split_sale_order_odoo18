{
    'name': 'Split Sale Order',
    'version': '1.0',
    'author': 'khush',
    'depends': ['sale_stock'],
    'data': [
        'security/ir.model.access.csv',
        'security/split_sale_security.xml',
        'views/res_config_setting_views.xml',
        'views/split_sale_order.xml',
    ],
    'application': True,
}