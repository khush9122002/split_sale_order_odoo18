from odoo import models, fields, api
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = 'sale.order'
  
    split_from=fields.Many2one("sale.order",string="Splited From")
    split_count=fields.Integer(compute="compute_split_count")
    extract_count=fields.Integer(compute="compute_extract_count")
    sale_order_line_id = fields.Many2one('sale.order.line', string="Product")
    extract_from=fields.Many2one("sale.order", string="Extracted From")


    def split_quotation(self):
        selected_lines = self.order_line.filtered(lambda l: l.product)  
          
        if not selected_lines:
            selected_lines = self.order_line  

        ctx = self.env.context.copy()
        ctx.update({
            'default_product_lines': [
                (0, 0, {  
                    'product_id': line.product_id.id,  
                    'quantity': line.product_uom_qty,
                    'sale_order_line_id': line.id
                }) for line in selected_lines if line.product_id
            ]
        })
        return {
            'type': 'ir.actions.act_window',
            'name': 'Split Quotation',
            'res_model': 'split.order.wizard',
            'view_id': self.env.ref('split_sale_order.split_wizard_form').id,
            'view_mode': 'form',
            'target': 'new',
            'context': ctx,
        }

    def extract_quotation(self):
        selected_line_ids = self.order_line.filtered(lambda l: l.product).ids
        if not selected_line_ids:   
            raise ValidationError("Please select at least one order line to split!")
        
        new_order = self.copy({
            'order_line': [], 
            'origin': self.name,
            'extract_from': self.id, 

        })
        # Copy selected lines to new order
        selected_lines = self.env['sale.order.line'].browse(selected_line_ids)
        for line in selected_lines:
            line.copy({
                'order_id': new_order.id,
                'product_uom_qty': line.product_uom_qty,
            })
        
        return {
            'type': 'ir.actions.act_window',
            'name': 'Split Order',  
            'res_model': 'sale.order',
            'res_id': new_order.id,
            'view_mode': 'form',
            'target': 'current',
        }
    def action_select_all_lines(self):
        """Select all order lines"""
        self.ensure_one()
        self.order_line.write({'product': True})
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }


    def unselect_all(self):
        """UnSelect all order lines"""
        self.ensure_one()
        self.order_line.write({'product': False})
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
    def compute_split_count(self):      
        for rec in self:
            rec.split_count=self.env["sale.order"].search_count([("split_from" ,"=" ,self.name)])
    
    def compute_extract_count(self):      
        for rec in self:
            rec.extract_count=self.env["sale.order"].search_count([("extract_from" ,"=" ,self.name)])

    def split_sale_count(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Split Orders',
            'res_model': 'sale.order',
            'view_mode': 'list,form',
            'domain': [('split_from', '=', self.name)],
        }
    def extract_sale_count(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Extract  Orders',
            'res_model': 'sale.order',
            'view_mode': 'list,form',
            'domain': [('extract_from', '=', self.name)],
        }


class saleorderline(models.Model):
    _inherit="sale.order.line"
    
    product=fields.Boolean("Select Product")

    def tick_untick(self):
        self.product = not self.product
        return True

class SplitOrderLine(models.TransientModel):
    _name = 'split.order.line'
    _description = 'Split Order Line'

    wizard_id = fields.Many2one('split.order.wizard', string='Wizard Reference', required=True)
    product_id = fields.Many2one('product.product', string='Product')
    sale_order_line_id = fields.Many2one('sale.order.line', string="Product")
    quantity = fields.Float(string='Split Quantity')


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    split_sale_order_qty = fields.Boolean(
        string="Remove Splitted Qty from SO/Quotation",
        config_parameter='sale.split_sale_order_qty'
    )
